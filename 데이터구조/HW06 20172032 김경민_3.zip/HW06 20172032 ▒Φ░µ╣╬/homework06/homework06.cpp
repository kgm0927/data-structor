#define _CRT_SECURE_NO_WARNINGS
#include <string.h>
#include<stdio.h>
#include <stdlib.h>
#define empty(item) (strlen(item.key1)==0)
#define equal(item1,item2)(item1.id==item2.id)

#define KEY_SIZE 10
#define TABLE_SIZE 120


struct record {
	int id;
	char name[10];
	int score[5];
	
}data[11] = {
	1, "�� ��",{95,78,23,89,23},
	2, "�� ��",{79,100,24,88,99},
	3, "�� ��",{24,82,21,79,23},
	4, "�� ��",{77,33,87,35,67},
	5, "�� ��",{80,78,86,54,23},
	6, "õ ��",{100,68,87,24,88},
	7, "�� ��",{57,98,54,89,19},
	8, "�� ��",{33,12,84,12,90},
	9, "ȫ ��",{98,87,88,99,30},
	10, "Ȳ ��",{98,87,88,99,30},
	11, "�� ��",{28,85,100,80,86}

};
char course[5][10] = { "����","����","����","����","��ȸ" };



typedef struct {
	char key1[KEY_SIZE];
	char key2[KEY_SIZE];
	int id;
	int score;
}element;


element hash_table[TABLE_SIZE];

void init_table(element ht[]) {
	int i;
	for (i = 0; i < TABLE_SIZE; i++) {
		ht[i].key1[0] = ' \0';
		ht[i].key2[0] = ' \0';
		ht[i].id = 0;
		ht[i].score = -1;
	}
}



int hash_function1(int id, char* key) {

	int i = 0;
	for (; i < 5; i++) {
		if (!strcmp(key, course[i]))break;
	}

	return id * 10 + i;

}

int hash_function2(char *key1, char* key2) {
	int i = 1;

	for (; i < 12; i++)
		if (!strcmp(key1, data[i].name))break;

	i++;

	return hash_function1(data[i].id, key2);

}

void hash_lp_add(element item, element ht[]) {
	int i, hash_value;
	hash_value = i = hash_function1(item.id, item.key2);

	while (!empty(ht[i])) {
		if (equal(item, ht[i])) {
			fprintf(stderr, "Ž�� %s: ��ġ =%d\n", item.key1, i);
			exit(1);
		}
		i = (i + 1) % TABLE_SIZE;

		if (i == hash_value) {
			fprintf(stderr, " ã�� ���� ���̺��� ����\n");
			exit(1);
		}

	}
	ht[i] = item;
}

void hash_lp_search1(element item, element ht[]) {
	int i, hash_value;
	hash_value = i = hash_function1(item.id, item.key2);

	while (!empty(ht[i])) {
		if (equal(item, ht[i])) {
			fprintf(stderr, "Ž�� %s    %s: ��ġ =%d\n", item.key1, item.key2, i);
	
			return;
		}
		i = (i + 1) % TABLE_SIZE;

		if (i == hash_value) {
			fprintf(stderr, " ã�� ���� ���̺��� ����\n");
			return;
		}

	}
	fprintf(stderr, "ã�� ���� ���̺��� ����\n");
}

void hash_lp_search2(element item, element ht[]) {
	
	int i, hash_value;

	hash_value = i = hash_function2(item.key1, item.key2);

	while (!empty(ht[i])) {
		if (equal(item, ht[i])) {
			fprintf(stderr, "Ž�� %s    %s: ��ġ =%d\n", item.key1,item.key2 ,i);
			return;
		}
		i = (i + 1) % TABLE_SIZE;

		if (i == hash_value) {
			fprintf(stderr, " ã�� ���� ���̺��� ����\n");
			return;
		}
	}
	fprintf(stderr, "ã�� ���� ���̺��� ����\n");

}


void hash_lp_print(element ht[]) {
	int i;
	printf("\n===============================\n");
	for (i = 0; i < TABLE_SIZE; i++) {
		printf("[%d]	%s %s %d\n", ht[i].id, ht[i].key1,ht[i].key2,ht[i].score);
	}
	printf("=======================================\n");
}

int main(void) {
	element e;

	for (int i = 0; i < 11; i++) {

		strcpy(e.key1, data[i].name);
		e.id = data[i].id;

		for (int j = 0; j < 5; j++) {

			strcpy(e.key2, course[j]);
			e.score = data[i].score[j];
			hash_lp_add(e, hash_table);
			
		}
		hash_lp_print(hash_table);
	}

	strcpy(e.key1, data[3].name);
	e.id = data[3].id;
	strcpy(e.key2, course[3]);
	//e.score = data[i].score[3];

		hash_lp_search1(e, hash_table);
		hash_lp_search2(e, hash_table);

		return 0;

}