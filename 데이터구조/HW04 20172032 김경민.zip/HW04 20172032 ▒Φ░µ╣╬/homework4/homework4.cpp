#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include<iostream>
#include<stdlib.h>
#include <string.h>
#include<fstream>

using namespace std;


#define MAX_ELEMENT 1000

typedef struct TreeNode {
	int weight;
	char ch;
	struct TreeNode* left;
	struct TreeNode* right;

}TreeNode;

typedef struct{
	TreeNode * ptree;
char ch;
int key;
}element;

typedef struct {
	element heap[MAX_ELEMENT];
	int heap_size;
}HeapType;

char* code_table[256];


HeapType* create() {
	return (HeapType*)malloc(sizeof(HeapType));
}

void init(HeapType* h) {
	h->heap_size = 0;
}

void insert_min_heap(HeapType* h, element item) {
	int i;
	i = ++(h->heap_size);

	while ((i != 1) && (item.key < h->heap[i / 2].key)) {
		h->heap[i] = h->heap[i / 2];
		i /= 2;
	}

	h->heap[i] = item;


}

element delete_min_heap(HeapType* h) {
	int parent, child;
	element item, temp;

	item = h->heap[1];
	temp = h->heap[(h->heap_size)--];

	parent = 1;
	child = 2;

	while (child <= h->heap_size) {
		if ((child <= h->heap_size) && (h->heap[child].key) > h->heap[child + 1].key) {
			child++;
		}

		if (temp.key < h->heap[child].key)break;

		h->heap[parent] = h->heap[child];
		parent = child;
		child *= 2;


	}
	h->heap[parent] = temp;
	return item;

}

TreeNode* make_tree(TreeNode* left, TreeNode* right) {
	TreeNode* node = (TreeNode*)malloc(sizeof(TreeNode));
	node->left = left;
	node->right = right;
	return node;
}

void destroy_tree(TreeNode* root) {
	if (root ==NULL)return;
	destroy_tree(root->left);
	destroy_tree(root->right);
	free(root);
}

int is_leaf(TreeNode* root) {
	return !(root->left) && !(root->right);
}

void print_array(int codes[], int n) {
	for (int i = 0; i < n; i++) {
		printf("%d", codes[i]);
	}
	printf("\n");
}

void array_to_string(char ch, int codes[], int n) {

	code_table[ch] = (char*)malloc(sizeof(char) * n + 1);
	for (int i = 0; i < n; i++) {
		*(code_table[ch] + i) = codes[i] + '0';

	}
	*(code_table[ch] + n) = '\0';
	

}

void print_codes(TreeNode* root, int codes[], int top) {

	if (root->left) {
		codes[top] = 1;
		print_codes(root->left, codes, top + 1);
	}

	if (root->right) {
		codes[top] = 0;
		print_codes(root->right, codes, top + 1);
	}

	if (is_leaf(root)) {
		printf("%c : ", root->ch);
		print_array(codes, top);
		array_to_string(root->ch,codes, top);
		
	}


}

TreeNode* huffman_tree(int freq[], char ch_list[], int n) {

	int i;
	TreeNode* node, * x;
	HeapType* heap;
	element e, e1, e2;
	int codes[128];
	int top = 0;

	heap = create();
	init(heap);
	int skip = 0;
	for (i = 0; i < n; i++) {
		if (freq[i] == 0) { skip++; continue; }
		node = make_tree(NULL, NULL);
		e.ch = node->ch = ch_list[i];
		e.key = node->weight = freq[i];
		e.ptree = node;
		insert_min_heap(heap, e);
	}
	for (i = 1; i < n-skip; i++) {
		e1 = delete_min_heap(heap);
		e2 = delete_min_heap(heap);

		x = make_tree(e1.ptree, e2.ptree);
		e.key = x->weight = e1.key + e2.key;
		e.ptree = x;
		printf("%d+%d->%d\n", e1.key, e2.key, e.key);
		insert_min_heap(heap, e);
	}
	e = delete_min_heap(heap);
	print_codes(e.ptree, codes, top);


	

	return e.ptree;

}

int encode(char input[], int len, char* output) {
	int offset = 0;
	for (int i = 0; i < len; i++) {
		cout << offset << " " << input[i] << "code" << code_table[(int)input[i]] << endl;
		strcpy(&output[offset], code_table[input[i]]);
		cout << "cp" << endl;
		offset += strlen(code_table[input[i]]);
		cout << "len" << endl;
	}
	return offset;
}


int decode(char h_code[], int len, TreeNode* h_tree, char* ret) {
	
	int offset = 0;
	TreeNode* cur = h_tree;

	for (int i = 0; i < len; i++) {
		if (h_code[i] == '1') {
			cur = cur->left;
		}
		else {
			cur = cur->right;
		}
		if (cur->left == NULL && cur->right == NULL) {
			ret[offset++] = cur->ch;
			cur = h_tree;
		}
	}

	return offset;

}

int main(void) {

	char ch_list[128];
	int freq[128];

	for (int i = 0; i < 128; i++) {
		ch_list[i] = i;
		freq[i] = 0;
	}
	ifstream in("ds.txt");
	ofstream fout("ds_zipped.txt");

	if (in.fail()) {
		cout << "������ ���� �� �����߽��ϴ�." << endl;
		return 0;
	}

	char line[501];
	in.read(line, 500);
	

	in.close();

	for (int i = 0; i < 500; i++) if (line[i] < 128 && line[i] >= 0) freq[line[i]]++; else line[i]=' ';

	TreeNode* h_tree = huffman_tree(freq, ch_list, 128);

	char output[5000];
	int offset = encode(line, 500, output);
	output[offset] = '\0';
	
	cout << output << endl;

	char ret[5000];
	decode(output, offset, h_tree, ret);
	cout << ret << endl;

	return 0;

	
	


}